import React from "react";

const AuthRightContainer = () => {
  return (
    <div className="col-lg-5 mb-4 mb-lg-0 px-lg-0">
      <div className="ct_login_right_img">
        <img src="assets/img/login_right_img.png" alt="" />
      </div>
    </div>
  );
};

export default AuthRightContainer;
