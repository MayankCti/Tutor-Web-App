import React from "react";

const AstrickMark = () => {
  return <span class="ct_required_star">*</span>;
};

export default AstrickMark;
